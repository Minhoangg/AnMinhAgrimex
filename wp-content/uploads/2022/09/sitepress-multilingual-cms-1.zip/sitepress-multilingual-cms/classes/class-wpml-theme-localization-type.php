<?php

/**
 * @deprecated since WPML 4.2.8
 *
 * Some constants are used in other projects, but it should be removed soon.
 */
class WPML_Theme_Localization_Type {
	const USE_ST                 = 1;
	const USE_MO_FILES           = 2;
	const USE_ST_AND_NO_MO_FILES = 3;
}
