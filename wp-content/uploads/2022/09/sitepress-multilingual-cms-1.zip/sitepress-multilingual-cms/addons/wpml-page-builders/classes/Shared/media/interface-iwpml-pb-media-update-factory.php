<?php

interface IWPML_PB_Media_Update_Factory {

	/** @return IWPML_PB_Media_Update */
	public function create();
}
