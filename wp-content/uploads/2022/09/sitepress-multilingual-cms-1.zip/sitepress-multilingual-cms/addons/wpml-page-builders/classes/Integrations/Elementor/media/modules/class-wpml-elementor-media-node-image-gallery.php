<?php

class WPML_Elementor_Media_Node_Image_Gallery extends WPML_Elementor_Media_Node_With_Images_Property {

	protected function get_property_name() {
		return 'wp_gallery';
	}
}